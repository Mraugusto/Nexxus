import { ethers } from "hardhat";
import * as fs from "fs";
import * as path from "path";
import "dotenv/config";

async function main() {
  const name = process.env.TOKEN_NAME || "Nexus Protocol";
  const symbol = process.env.TOKEN_SYMBOL || "NEX";
  const maxSupply = ethers.parseUnits("1000000000", 18); // 1B
  const [deployer] = await ethers.getSigners();
  console.log("Deployer:", deployer.address);

  // 1) Token
  const Token = await ethers.getContractFactory("NexusToken");
  const token = await Token.deploy(name, symbol, maxSupply, deployer.address);
  await token.waitForDeployment();
  console.log("NexusToken:", await token.getAddress());

  // 2) Staking
  const Staking = await ethers.getContractFactory("NexusStakingRewards");
  const staking = await Staking.deploy(await token.getAddress());
  await staking.waitForDeployment();
  console.log("NexusStakingRewards:", await staking.getAddress());

  // 3) Vesting Factory
  const VF = await ethers.getContractFactory("NexusVestingFactory");
  const vestingFactory = await VF.deploy(await token.getAddress(), deployer.address);
  await vestingFactory.waitForDeployment();
  console.log("NexusVestingFactory:", await vestingFactory.getAddress());

  // 4) Airdrop Factory
  const AF = await ethers.getContractFactory("NexusMerkleDistributorFactory");
  const airdropFactory = await AF.deploy(await token.getAddress(), deployer.address);
  await airdropFactory.waitForDeployment();
  console.log("NexusMerkleDistributorFactory:", await airdropFactory.getAddress());

  // 5) Optionally seed staking rewards
  const reward = process.env.STAKING_REWARD || "0";
  const durationDays = Number(process.env.STAKING_DURATION_DAYS || "0");
  if (Number(reward) > 0 && durationDays > 0) {
    const amount = ethers.parseUnits(reward.toString(), 18);
    await (await token.mint(await staking.getAddress(), amount)).wait();
    const duration = BigInt(durationDays) * 24n * 3600n;
    await (await staking.notifyRewardAmount(amount, duration)).wait();
    console.log("Seeded staking:", reward, "over", durationDays, "days");
  }

  // 6) Write addresses into /web/.env.local
  const webEnv = path.resolve(__dirname, "../../web/.env.local");
  const content = [
    `NEXT_PUBLIC_NEX_TOKEN_ADDRESS=${await token.getAddress()}`,
    `NEXT_PUBLIC_STAKING_ADDRESS=${await staking.getAddress()}`,
    `NEXT_PUBLIC_VESTING_FACTORY=${await vestingFactory.getAddress()}`,
    `NEXT_PUBLIC_AIRDROP_FACTORY=${await airdropFactory.getAddress()}`,
  ].join("\n") + "\n";
  fs.writeFileSync(webEnv, content, { encoding: "utf-8" });
  console.log("Wrote", webEnv);

  // 7) Save addresses.json for reference
  const addrJson = path.resolve(__dirname, "../addresses.json");
  fs.writeFileSync(addrJson, JSON.stringify({
    token: await token.getAddress(),
    staking: await staking.getAddress(),
    vestingFactory: await vestingFactory.getAddress(),
    airdropFactory: await airdropFactory.getAddress()
  }, null, 2));
  console.log("Saved addresses.json");
}

main().catch((e)=>{ console.error(e); process.exit(1); });
