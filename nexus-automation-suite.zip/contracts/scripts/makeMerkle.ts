import { ethers } from "hardhat";
import * as fs from "fs";
import * as path from "path";
import { parse } from "csv-parse/sync";

function keccak256(data: string): string {
  return ethers.keccak256(ethers.toUtf8Bytes(data));
}

function hashLeaf(index: number, account: string, amount: bigint): string {
  // abi.encode(index, account, amount) but we simulate with packed 32-byte slots
  const indexHex = ethers.zeroPadValue(ethers.toBeHex(index), 32);
  const acct = ethers.zeroPadValue(account as `0x${string}`, 32);
  const amountHex = ethers.zeroPadValue(ethers.toBeHex(amount), 32);
  return ethers.keccak256(ethers.concat([indexHex, acct, amountHex]));
}

function sortPair(a: string, b: string): [string, string] {
  return a.toLowerCase() < b.toLowerCase() ? [a,b] : [b,a];
}

function buildMerkle(leaves: string[]) {
  let layer = leaves;
  const layers: string[][] = [layer];
  while (layer.length > 1) {
    const next: string[] = [];
    for (let i=0;i<layer.length;i+=2){
      const left = layer[i];
      const right = i+1<layer.length ? layer[i+1] : left;
      const [a,b] = sortPair(left, right);
      next.push(ethers.keccak256(ethers.concat([ethers.getBytes(a), ethers.getBytes(b)])));
    }
    layer = next;
    layers.push(layer);
  }
  return { root: layers[layers.length-1][0] };
}

async function main() {
  const csvPath = process.env.AIRDROP_CSV || path.resolve(__dirname, "../airdrop.csv");
  const raw = fs.readFileSync(csvPath, "utf-8");
  const rows = parse(raw, { relaxColumnCount: true, skip_empty_lines: true });
  const entries = rows.map((r: any[], idx: number) => {
    const addr = String(r[0]).trim();
    const amt = BigInt(String(r[1]).trim());
    const leaf = hashLeaf(idx, addr, amt);
    return { index: idx, account: addr, amount: amt, leaf };
  });
  const { root } = buildMerkle(entries.map(e=>e.leaf));
  console.log("Merkle Root:", root);

  // Deploy distributor via factory
  const factoryAddr = process.env.AIRDROP_FACTORY || process.env.NEXT_PUBLIC_AIRDROP_FACTORY;
  if (!factoryAddr) {
    console.log("Set AIRDROP_FACTORY to deploy distributor. Only computing root.");
    return;
  }
  const [signer] = await ethers.getSigners();
  const factory = await ethers.getContractAt("NexusMerkleDistributorFactory", factoryAddr, signer);
  const tx = await factory.createDistributor(root as `0x${string}`);
  const rcpt = await tx.wait();
  console.log("Distributor deployed in tx:", rcpt?.hash);

  // Optional: fetch last distributor
  // (ABI has getAll())
  try {
    const list: string[] = await factory.getAll();
    console.log("Latest Distributor:", list[list.length-1]);
  } catch {}
}

main().catch(e=>{ console.error(e); process.exit(1); });
