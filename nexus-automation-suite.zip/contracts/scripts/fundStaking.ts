import { ethers } from "hardhat";
import "dotenv/config";

// Funds staking with NEX and calls notifyRewardAmount(reward, durationSeconds)
async function main() {
  const stakingAddr = process.env.STAKING || process.env.NEXT_PUBLIC_STAKING_ADDRESS;
  const tokenAddr = process.env.TOKEN || process.env.NEXT_PUBLIC_NEX_TOKEN_ADDRESS;
  const reward = ethers.parseUnits(process.env.REWARD || "0", 18);
  const duration = BigInt(process.env.DURATION || "0");

  if (!stakingAddr || !tokenAddr) throw new Error("Set STAKING and TOKEN");
  if (reward === 0n || duration === 0n) throw new Error("Set REWARD and DURATION");

  const [signer] = await ethers.getSigners();
  const token = await ethers.getContractAt("NexusToken", tokenAddr, signer);
  const staking = await ethers.getContractAt("NexusStakingRewards", stakingAddr, signer);

  await (await token.mint(stakingAddr, reward)).wait();
  await (await staking.notifyRewardAmount(reward, duration)).wait();
  console.log("Seeded staking with", reward.toString(), "over", duration.toString(), "seconds");
}

main().catch(e=>{ console.error(e); process.exit(1); });
