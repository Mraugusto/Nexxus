# Nexus Monorepo (Contracts + Web)

This repo makes your life easy: **one command** to deploy contracts and configure the web app automatically.

## Quick Start (local, Sepolia)
```bash
# 1) Contracts
cd contracts
cp .env.example .env
# edit .env with PRIVATE_KEY and ALCHEMY_KEY
npm i
npm run compile
npm run deploy:sepolia
# => writes web/.env.local with deployed addresses

# 2) Web
cd ../web
npm i
npm run dev
```

## Optional
- Fund staking rewards:
```bash
cd contracts
STAKING=0xStaking TOKEN=0xToken REWARD=1000000 DURATION=$((30*24*3600)) npx hardhat run scripts/fundStaking.ts --network sepolia
```

- Airdrop from CSV:
```bash
cd contracts
# edit airdrop.csv
AIRDROP_FACTORY=0xFactory npx hardhat run scripts/makeMerkle.ts --network sepolia
```

## CI/CD (optional, GitHub Actions)
- Add repo secrets:
  - `PRIVATE_KEY`, `ALCHEMY_KEY` (for contracts)
  - `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID` (for Web auto-deploy).
- Trigger **Deploy Contracts** workflow manually.
- On success, artifacts include the generated `.env.local` for the `web` app.

> Security: Use a **test wallet** in CI. For mainnet, switch network and require manual approvals/multisig.
