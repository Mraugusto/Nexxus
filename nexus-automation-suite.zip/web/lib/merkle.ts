import { keccak256, toUtf8Bytes, getBytes, concat, hexlify, zeroPadValue } from "ethers";

type Leaf = { index: number; account: string; amount: bigint };

/** Hash leaf with ABI-like encoding: keccak256(abi.encode(index, account, amount)) */
export function hashLeaf(l: Leaf): string {
  const indexHex = zeroPadValue(hexlify(l.index), 32);
  const acct = zeroPadValue(l.account as `0x${string}`, 32);
  const amountHex = zeroPadValue(hexlify(l.amount), 32);
  return keccak256(concat([indexHex, acct, amountHex]));
}

function sortPair(a: string, b: string): [string, string] {
  return a.toLowerCase() < b.toLowerCase() ? [a,b] : [b,a];
}

export function buildMerkle(leaves: Leaf[]) {
  const layer0 = leaves.map(hashLeaf);
  let layers: string[][] = [layer0];
  let layer = layer0;
  while (layer.length > 1) {
    const next: string[] = [];
    for (let i=0; i<layer.length; i+=2) {
      const left = layer[i];
      const right = i+1 < layer.length ? layer[i+1] : left;
      const [a,b] = sortPair(left, right);
      next.push(keccak256(concat([getBytes(a), getBytes(b)])));
    }
    layer = next;
    layers.push(layer);
  }
  const root = layers[layers.length-1][0];
  const proofs: string[][] = [];
  for (let i=0; i<leaves.length; i++) {
    const path: string[] = [];
    let idx = i;
    for (let level=0; level<layers.length-1; level++) {
      const arr = layers[level];
      const pairIndex = idx ^ 1;
      path.push(arr[pairIndex] ?? arr[idx]); // duplicate if no pair
      idx = Math.floor(idx/2);
    }
    proofs[i] = path;
  }
  return { root, layers, proofs };
}
