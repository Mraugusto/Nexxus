'use client';

import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';

// ======= CONFIG =======
// Replace with your deployed addresses:
const TOKEN_ADDRESS = process.env.NEXT_PUBLIC_NEX_TOKEN_ADDRESS || '0xYourNEXAddress';
const FACTORY_ADDRESS = process.env.NEXT_PUBLIC_VESTING_FACTORY || '0xYourVestingFactory';

const factoryAbi = [
  "function createVesting(address beneficiary,uint64 start,uint64 cliffDuration,uint64 duration,bool revocable) onlyOwner returns (address)",
  "function batchCreate(address[] beneficiaries,uint64[] starts,uint64[] cliffs,uint64[] durations,bool[] revocables) onlyOwner returns (address[] memory)",
  "function vestingsOf(address) view returns (address[])"
];

export default function VestingPage() {
  const [account, setAccount] = useState<string>('');
  const [provider, setProvider] = useState<ethers.BrowserProvider>();
  const [signer, setSigner] = useState<ethers.Signer>();
  const [status, setStatus] = useState<string>('');
  const [csv, setCsv] = useState<string>('0xabc...,100000,2025-10-01,12,48,true\n0xdef...,200000,2026-01-01,0,60,false');
  const [created, setCreated] = useState<string[]>([]);

  const factory = useMemo(() => (signer ? new ethers.Contract(FACTORY_ADDRESS, factoryAbi, signer) : null), [signer]);

  async function connect() {
    if (!window.ethereum) return alert("MetaMask not found");
    const prov = new ethers.BrowserProvider(window.ethereum as any);
    const acc = await prov.send('eth_requestAccounts', []);
    const s = await prov.getSigner();
    setProvider(prov);
    setSigner(s);
    setAccount(acc[0]);
  }

  function parseCsv() {
    // columns: beneficiary, amountTokens, start(YYYY-MM-DD), cliffMonths, durationMonths, revocable
    const lines = csv.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
    const entries = [];
    for (const l of lines) {
      const [beneficiary, amount, startDate, cliffM, durationM, rev] = l.split(/,|;|\t/).map(x=>x.trim());
      const start = Math.floor(new Date(startDate+"T00:00:00Z").getTime()/1000);
      const cliff = parseInt(cliffM||"0",10) * 30 * 24 * 3600; // approx
      const duration = parseInt(durationM||"0",10) * 30 * 24 * 3600;
      const revocable = /^true|1|yes$/i.test(rev||"true");
      entries.push({ beneficiary, amount, start, cliff, duration, revocable });
    }
    return entries;
  }

  async function handleBatchCreate() {
    if (!factory) return;
    try {
      const rows = parseCsv();
      const beneficiaries = rows.map(r=>r.beneficiary);
      const starts = rows.map(r=>r.start);
      const cliffs = rows.map(r=>r.cliff);
      const durations = rows.map(r=>r.duration);
      const revocables = rows.map(r=>r.revocable);
      setStatus('Creating vestings...');
      const tx = await factory.batchCreate(beneficiaries, starts, cliffs, durations, revocables);
      const rcpt = await tx.wait();
      setStatus('Batch created.');
    } catch (e:any) {
      setStatus(e.message || 'Error');
    }
  }

  return (
    <main className="min-h-screen bg-[#0b0b0f] text-white px-6 py-10">
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-3xl font-semibold">Vesting Factory</h1>
        {!account ? (
          <button onClick={connect} className="rounded-xl px-4 py-2 bg-white text-black">Connect Wallet (Owner)</button>
        ) : (<div className="text-sm text-white/80 break-all">Connected: {account}</div>)}

        <div className="rounded-2xl border border-white/15 bg-white/5 p-4 space-y-3">
          <label className="text-sm">CSV (beneficiary, amountTokens, start(YYYY-MM-DD), cliffMonths, durationMonths, revocable)</label>
          <textarea value={csv} onChange={(e)=>setCsv(e.target.value)} rows={6} className="w-full rounded-xl bg-white/10 px-4 py-3 outline-none ring-1 ring-white/15 focus:ring-2 focus:ring-emerald-400"></textarea>
          <button onClick={handleBatchCreate} className="rounded-xl px-4 py-2 bg-white text-black">Create Vestings (batch)</button>
          <div className="text-xs text-white/70">{status}</div>
        </div>
      </div>
    </main>
  );
}
