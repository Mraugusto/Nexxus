'use client';
import { useState } from 'react';
import { ethers } from 'ethers';
import { dict, type Lang } from '@/components/i18n';

const FACTORY = process.env.NEXT_PUBLIC_VESTING_FACTORY || '0xYourVestingFactory';
const factoryAbi = ["function vestingsOf(address) view returns (address[])"];
const vestingAbi = [
  "function beneficiary() view returns (address)",
  "function start() view returns (uint64)",
  "function cliff() view returns (uint64)",
  "function duration() view returns (uint64)",
  "function released() view returns (uint256)",
  "function revoked() view returns (bool)",
  "function releasable() view returns (uint256)"
];

export default function ExplorerPage() {
  const [lang, setLang] = useState<Lang>('en');
  const t = dict[lang];
  const [addr, setAddr] = useState<string>('');
  const [rows, setRows] = useState<any[]>([]);
  const [status, setStatus] = useState<string>('');

  async function lookup() {
    try {
      const provider = new ethers.BrowserProvider((window as any).ethereum);
      const signer = await provider.getSigner();
      const factory = new ethers.Contract(FACTORY, factoryAbi, signer);
      setStatus('Loading...');
      const list: string[] = await factory.vestingsOf(addr);
      const res: any[] = [];
      for (const vAddr of list) {
        const v = new ethers.Contract(vAddr, vestingAbi, signer);
        const [beneficiary, start, cliff, duration, released, revoked, releasable] = await Promise.all([
          v.beneficiary(), v.start(), v.cliff(), v.duration(), v.released(), v.revoked(), v.releasable()
        ]);
        res.push({ vesting: vAddr, beneficiary, start: Number(start), cliff: Number(cliff), duration: Number(duration), released: ethers.formatUnits(released, 18), revoked, releasable: ethers.formatUnits(releasable, 18) });
      }
      setRows(res);
      setStatus('');
    } catch(e:any) {
      setStatus(e.message || 'Error');
    }
  }

  return (
    <main className="min-h-screen bg-[#0b0b0f] text-white px-6 py-10">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-semibold">{t.explorerTitle}</h1>
          <select value={lang} onChange={e=>setLang(e.target.value as Lang)} className="bg-white/10 border border-white/15 rounded-lg px-3 py-2 text-sm">
            {Object.entries(dict).map(([k,v])=> <option key={k} value={k}>{v.langName}</option>)}
          </select>
        </div>
        <p className="text-white/70">{t.explorerDesc}</p>

        <div className="rounded-2xl border border-white/15 bg-white/5 p-4 space-y-3">
          <label className="text-sm">Beneficiary address</label>
          <div className="flex gap-2">
            <input value={addr} onChange={e=>setAddr(e.target.value)} placeholder="0x..." className="flex-1 rounded-xl bg-white/10 px-4 py-3 outline-none ring-1 ring-white/15 focus:ring-2 focus:ring-emerald-400" />
            <button onClick={lookup} className="rounded-xl px-4 py-2 bg-white text-black">Lookup</button>
          </div>
          {status && <div className="text-xs text-white/70">{status}</div>}
          <div className="overflow-x-auto">
            <table className="w-full text-sm mt-3">
              <thead className="text-white/70"><tr><th className="text-left p-2">Vesting</th><th className="text-left p-2">Start</th><th className="text-left p-2">Cliff</th><th className="text-left p-2">Duration</th><th className="text-left p-2">Released</th><th className="text-left p-2">Releasable</th><th className="text-left p-2">Revoked</th></tr></thead>
              <tbody>
                {rows.map((r,i)=>(
                  <tr key={i} className="border-t border-white/10">
                    <td className="p-2">{r.vesting}</td>
                    <td className="p-2">{new Date(r.start*1000).toISOString().slice(0,10)}</td>
                    <td className="p-2">{new Date(r.cliff*1000).toISOString().slice(0,10)}</td>
                    <td className="p-2">{Math.round(r.duration/86400)}d</td>
                    <td className="p-2">{r.released}</td>
                    <td className="p-2">{r.releasable}</td>
                    <td className="p-2">{String(r.revoked)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </main>
  );
}
