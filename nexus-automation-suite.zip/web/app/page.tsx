'use client';

import Image from "next/image";
import Link from "next/link";
import { motion, MotionConfig } from "framer-motion";
import { Globe2, ShieldCheck, Link as LinkIcon, Building2, LockKeyhole, Scale, FileText, Download, BarChart3, Rocket } from "lucide-react";
import { ResponsiveContainer, PieChart, Pie, Cell, Legend, Tooltip } from "recharts";
import { useState } from "react";
import NewsletterForm from "@/components/NewsletterForm";
import { dict, type Lang } from "@/components/i18n";

const LINKS = {
  whitepaperPT: "sandbox:/mnt/data/Nexus_Whitepaper_PT.pdf",
  whitepaperEN: "sandbox:/mnt/data/Nexus_Whitepaper_EN.pdf",
  pitch: "sandbox:/mnt/data/Nexus_PitchDeck.pdf",
  tokenomics: "sandbox:/mnt/data/NEX_tokenomics.xlsx",
  contractToken: "sandbox:/mnt/data/NexusToken.sol",
  contractDAO: "sandbox:/mnt/data/NexusDAO.sol",
  fullZip: "sandbox:/mnt/data/Nexus_Protocol_FullPackage.zip",
  allZip: "sandbox:/mnt/data/Nexus_Protocol_Package.zip",
};

const tokenomicsData = [
  { name: "DAO Treasury", value: 25 },
  { name: "Network Incentives", value: 20 },
  { name: "Strategic Investors", value: 15 },
  { name: "Team (5y vesting)", value: 15 },
  { name: "Partnerships & Liquidity", value: 15 },
  { name: "Strategic Airdrop", value: 10 },
];

const COLORS = ["#60a5fa","#34d399","#fbbf24","#f472b6","#a78bfa","#22d3ee"];

function FeatureCard({ Icon, title, desc }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4 }}
      className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur shadow-sm hover:shadow-lg hover:bg-white/10 transition"
    >
      <div className="flex items-center gap-3">
        <div className="rounded-xl p-2 bg-white/10"><Icon className="w-6 h-6" /></div>
        <h3 className="text-lg font-semibold tracking-tight">{title}</h3>
      </div>
      <p className="mt-3 text-sm text-white/80 leading-relaxed">{desc}</p>
    </motion.div>
  );
}

function Stat({ label, value, sub }: {label:string, value:string, sub?:string}) {
  return (
    <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
      <div className="text-3xl font-semibold">{value}</div>
      <div className="text-white/70 text-sm mt-1">{label}</div>
      {sub && <div className="text-xs text-emerald-300 mt-2">{sub}</div>}
    </div>
  );
}

function Section({ id, eyebrow, title, children }: any) {
  return (
    <section id={id} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.p initial={{ opacity: 0, y: 6 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="uppercase tracking-widest text-xs text-white/60 mb-2">
        {eyebrow}
      </motion.p>
      <motion.h2 initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-2xl md:text-3xl font-semibold mb-8">
        {title}
      </motion.h2>
      {children}
    </section>
  );
}

function Header({ lang, setLang }: {lang:Lang, setLang:(l:Lang)=>void}) {
  const t = dict[lang];
  return (
    <header className="sticky top-0 z-40 backdrop-blur border-b border-white/10 bg-gradient-to-b from-black/50 to-transparent">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        <a href="#" className="flex items-center gap-3 group">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-sky-400 via-emerald-400 to-indigo-500 flex items-center justify-center shadow">
            <Globe2 className="w-5 h-5" />
          </div>
          <div>
            <div className="font-semibold leading-none tracking-tight group-hover:opacity-90">Nexus Protocol</div>
            <div className="text-xs text-white/60 -mt-0.5">{t.brandTag}</div>
          </div>
        </a>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="#features" className="hover:text-white/90 text-white/70">Features</a>
          <a href="#tokenomics" className="hover:text-white/90 text-white/70">Tokenomics</a>
          <a href="#roadmap" className="hover:text-white/90 text-white/70">Roadmap</a>
          <a href="#downloads" className="hover:text-white/90 text-white/70">Downloads</a>
        </nav>
        <div className="flex items-center gap-2">
          <a href={LINKS.whitepaperEN} className="rounded-xl px-3 py-2 text-sm font-medium bg-white text-black hover:bg-white/90 transition">{t.headerWP}</a>
          <button onClick={()=>setLang(lang === "en" ? "pt" : "en")} className="rounded-xl px-2.5 py-2 text-xs font-medium bg-white/10 hover:bg-white/20 border border-white/15">
            {lang === "en" ? t.headerPT : t.headerEN}
          </button>
        </div>
      </div>
    </header>
  );
}

function Hero({ lang }: {lang:Lang}) {
  const t = dict[lang];
  return (
    <div className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 pointer-events-none">
        <div className="absolute -top-56 -left-32 h-[36rem] w-[36rem] rounded-full bg-sky-500/20 blur-3xl" />
        <div className="absolute -bottom-40 -right-20 h-[28rem] w-[28rem] rounded-full bg-emerald-400/20 blur-3xl" />
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-12">
        <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-4xl md:text-6xl font-semibold leading-tight">
          {t.heroTitleA} <span className="bg-gradient-to-r from-sky-400 via-emerald-300 to-indigo-400 bg-clip-text text-transparent">{t.heroTitleB}</span>
        </motion.h1>
        <motion.p initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.6 }} className="mt-4 text-lg text-white/80 max-w-2xl">
          {t.heroDesc}
        </motion.p>
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }} className="mt-8 flex flex-wrap gap-3">
          <a href={LINKS.pitch} className="inline-flex items-center gap-2 rounded-2xl bg-white text-black px-5 py-3 font-medium shadow hover:bg-white/90">
            <Rocket className="w-4 h-4" /> {t.ctaPitch}
          </a>
          <a href={LINKS.tokenomics} className="inline-flex items-center gap-2 rounded-2xl border border-white/15 bg-white/10 px-5 py-3 font-medium hover:bg-white/20">
            <BarChart3 className="w-4 h-4" /> {t.ctaTokenomics}
          </a>
          <a href="#downloads" className="inline-flex items-center gap-2 rounded-2xl border border-white/10 px-5 py-3 hover:bg-white/10">
            <Download className="w-4 h-4" /> {t.ctaDownloads}
          </a>
        </motion.div>
      </div>
    </div>
  );
}

function Stats({ lang }: {lang:Lang}) {
  const t = dict[lang];
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
      <div className="grid md:grid-cols-3 gap-4">
        <Stat label={t.stat1} value="$500M" sub="Real-time on-chain audit" />
        <Stat label={t.stat2} value="> 200" sub="PoS with ZK compliance" />
        <Stat label={t.stat3} value="1,000,000,000" sub="Deflationary model" />
      </div>
    </div>
  );
}

function Features({ lang }: {lang:Lang}) {
  const t = dict[lang];
  const items = [
    { Icon: ShieldCheck, title: lang === "en" ? "Security & Audit" : "Segurança & Auditoria", desc: lang === "en" ? "PoS with zero-knowledge proofs, external audits, and DAO-controlled emergency pause." : "PoS com provas de conhecimento zero, auditorias externas e pausa emergencial por governança." },
    { Icon: LinkIcon, title: lang === "en" ? "Native cross-chain" : "Cross-chain nativo", desc: lang === "en" ? "Cosmos SDK + IBC, rollups for EVM & Solana, unified liquidity." : "Cosmos SDK + IBC, rollups para EVM e Solana, liquidez unificada." },
    { Icon: Building2, title: lang === "en" ? "Institutional-grade RWA" : "RWA pronto para Instituições", desc: lang === "en" ? "Enterprise SDK, per-issuer KYC/AML, compliance reporting." : "SDK empresarial, KYC/AML modular por emissor, relatórios de conformidade." },
    { Icon: LockKeyhole, title: lang === "en" ? "Privacy on your terms" : "Privacidade sob controle", desc: lang === "en" ? "ZKPs to prove compliance without exposing sensitive data." : "ZKPs para provar conformidade sem expor dados sensíveis." },
    { Icon: Scale, title: lang === "en" ? "Sustainable economics" : "Economia sustentável", desc: lang === "en" ? "Clear fees, buyback & burn, and staking incentives." : "Taxas claras, buyback & burn e incentivos de staking." },
    { Icon: Globe2, title: lang === "en" ? "Global standard" : "Padrão global", desc: lang === "en" ? "Governments, banks and fintechs can issue and trade tokenized assets." : "Governos, bancos e fintechs podem emitir e negociar ativos tokenizados." },
  ];
  return (
    <Section id="features" eyebrow={t.featuresEyebrow} title={t.featuresTitle}>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((it, i) => <FeatureCard key={i} Icon={it.Icon} title={it.title} desc={it.desc} />)}
      </div>
    </Section>
  );
}

function Tokenomics({ lang }: {lang:Lang}) {
  const t = dict[lang];
  return (
    <Section id="tokenomics" eyebrow={t.tokenomicsEyebrow} title={t.tokenomicsTitle}>
      <div className="grid lg:grid-cols-2 gap-10 items-center">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6 h-[360px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={tokenomicsData} dataKey="value" nameKey="name" innerRadius={70} outerRadius={120} paddingAngle={2}>
                {tokenomicsData.map((_, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
              </Pie>
              <Legend wrapperStyle={{ color: "#fff" }} />
              <Tooltip contentStyle={{ background: "#0b0b0b", border: "1px solid rgba(255,255,255,0.1)", color: "#fff" }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="space-y-4">
          <p className="text-white/80">{lang==="en" ? 
            "Fixed total supply of 1B NEX with deflation via buyback & burn of protocol fees. Utilities: gas, staking, governance and collateral for NexusUSD." :
            "Supply total fixo de 1B NEX, com modelo deflacionário via buyback & burn das taxas do protocolo. Utilidades: gas, staking, governança e colateral para a NexusUSD."
          }</p>
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            {tokenomicsData.map((d) => (
              <li key={d.name} className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 flex items-center justify-between">
                <span>{d.name}</span><span className="text-white/70">{d.value}%</span>
              </li>
            ))}
          </ul>
          <div className="pt-2 flex gap-3">
            <a href={LINKS.tokenomics} className="rounded-xl px-4 py-2 bg-white text-black font-medium inline-flex items-center gap-2"><BarChart3 className="w-4 h-4"/>Open sheet</a>
            <a href={LINKS.contractToken} className="rounded-xl px-4 py-2 border border-white/15 bg-white/10 hover:bg-white/20 inline-flex items-center gap-2"><FileText className="w-4 h-4"/>NEX Contract</a>
          </div>
        </div>
      </div>
    </Section>
  );
}

function Roadmap({ lang }: {lang:Lang}) {
  const t = dict[lang];
  const items = [
    { year: "2025", points: [ lang==="en" ? "Nexus mainnet + first RWAs" : "Mainnet Nexus + primeiros RWAs", "External audits & oracles", "Initial DEX listings" ]},
    { year: "2026", points: [ "EVM + Solana integrations", lang==="en"?"Institutional partnerships":"Parcerias institucionais", "500M USD tokenized" ]},
    { year: "2027", points: [ "NexusUSD stablecoin", "DAO & grants", "Tier-1 CEX" ]},
    { year: "2028–2030", points: [ "> 5–15B USD in RWAs", "dApp ecosystem on Nexus", lang==="en"?"Global tokenization standard":"Padrão global de tokenização" ]},
  ];
  return (
    <Section id="roadmap" eyebrow={t.roadmapEyebrow} title={t.roadmapTitle}>
      <div className="relative border-l border-white/15 pl-6">
        {items.map((it, idx) => (
          <motion.div key={it.year} initial={{ opacity: 0, x: -8 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: idx * 0.05 }} className="mb-10">
            <div className="absolute -left-[11px] mt-1 h-5 w-5 rounded-full bg-gradient-to-tr from-emerald-400 to-sky-500 border border-white/20" />
            <h3 className="text-xl font-semibold">{it.year}</h3>
            <ul className="mt-2 space-y-2 text-white/80 text-sm">
              {it.points.map((p, i) => <li key={i}>• {p}</li>)}
            </ul>
          </motion.div>
        ))}
      </div>
    </Section>
  );
}

function Downloads({ lang }: {lang:Lang}) {
  const t = dict[lang];
  const dl = [
    { label: lang==="en"?"Whitepaper (PT)":"Whitepaper (PT)", href: LINKS.whitepaperPT },
    { label: lang==="en"?"Whitepaper (EN)":"Whitepaper (EN)", href: LINKS.whitepaperEN },
    { label: lang==="en"?"Pitch Deck (PDF)":"Pitch Deck (PDF)", href: LINKS.pitch },
    { label: lang==="en"?"Tokenomics (XLSX)":"Tokenomics (XLSX)", href: LINKS.tokenomics },
    { label: lang==="en"?"NEX Contract (ERC-20)":"Contrato NEX (ERC-20)", href: LINKS.contractToken },
    { label: lang==="en"?"DAO Contract (Governance)":"Contrato DAO (Governança)", href: LINKS.contractDAO },
    { label: lang==="en"?"Complete Package (ZIP)":"Pacote Completo (ZIP)", href: LINKS.allZip },
    { label: lang==="en"?"Expanded Package (ZIP)":"Pacote Expandido (ZIP)", href: LINKS.fullZip },
  ];
  return (
    <Section id="downloads" eyebrow={t.downloadsEyebrow} title={t.downloadsTitle}>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {dl.map((item) => (
          <a key={item.label} href={item.href} className="group rounded-2xl border border-white/10 bg-white/5 p-5 hover:bg-white/10 transition">
            <div className="flex items-center justify-between">
              <div className="font-medium">{item.label}</div>
              <Download className="w-4 h-4 opacity-70 group-hover:opacity-100" />
            </div>
            <div className="text-xs text-white/60 mt-2">{lang==="en"?"Click to open":"Clique para abrir"}</div>
          </a>
        ))}
      </div>
    </Section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/10 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-white/70 text-sm">© {new Date().getFullYear()} Nexus Protocol — All rights reserved.</div>
        <div className="text-white/60 text-xs">Built for RWA tokenization • Cross-chain • ZK compliance</div>
      </div>
    </footer>
  );
}

export default function Page() {
  const [lang, setLang] = useState<Lang>("en");
  const t = dict[lang];
  return (
    <MotionConfig reducedMotion="user">
      <main className="min-h-screen text-white bg-[#0b0b0f]">
        <Header lang={lang} setLang={setLang} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4 pb-6">
          <div className="flex items-center gap-3 text-white/70 text-sm">
            <Image src="/logo.svg" width={18} height={18} alt="logo" />
            <span>{t.brandTag}</span>
          </div>
        </div>
        <Hero lang={lang} />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><NewsletterForm lang={lang} /></div>
        <div className="mt-8"><Stats lang={lang} /></div>
        <Features lang={lang} />
        <Tokenomics lang={lang} />
        <Roadmap lang={lang} />
        <Downloads lang={lang} />
        <Footer />
      </main>
    </MotionConfig>
  );
}
