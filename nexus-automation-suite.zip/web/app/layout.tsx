import type { Metadata } from "next";
import Script from "next/script";
import { Analytics } from "@vercel/analytics/react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nexus Protocol — Trust layer for RWAs",
  description: "Cross-chain infrastructure to tokenize real-world assets with security, compliance, and global liquidity.",
  metadataBase: new URL("https://nexus.example"), // update to your domain
  openGraph: {
    title: "Nexus Protocol — Trust layer for RWAs",
    description: "Cross-chain infrastructure to tokenize real-world assets with security, compliance, and global liquidity.",
    url: "https://nexus.example",
    type: "website",
    images: [{ url: "/og-image.png", width: 1200, height: 630, alt: "Nexus Protocol" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Nexus Protocol — Trust layer for RWAs",
    description: "Tokenize the world with a trust layer for RWAs.",
    images: ["/og-image.png"],
  },
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png" }],
  },
  manifest: "/site.webmanifest",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const gaId = process.env.NEXT_PUBLIC_GA_ID;
  return (
    <html lang="en">
      <head>
        {/* Google Analytics (optional): set NEXT_PUBLIC_GA_ID */}
        {gaId ? (
          <>
            <Script
              src={`https://www.googletagmanager.com/gtag/js?id=${gaId}`}
              strategy="afterInteractive"
            />
            <Script id="ga4" strategy="afterInteractive">
              {`
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${gaId}');
              `}
            </Script>
          </>
        ) : null}
      </head>
      <body className="min-h-screen">
        {children}
        <Analytics />
      </body>
    </html>
  );
}
