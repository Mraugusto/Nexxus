import { NextRequest, NextResponse } from "next/server";

/**
 * Newsletter subscription endpoint
 * Supports:
 *  - Brevo (Sendinblue): set BREVO_API_KEY and BREVO_LIST_ID
 *  - Mailchimp: set MAILCHIMP_API_KEY, MAILCHIMP_SERVER_PREFIX (e.g. us21), MAILCHIMP_LIST_ID
 * If none configured, returns 501 with instructions.
 */

export async function POST(req: NextRequest) {
  const { email } = await req.json();
  if (!email) return NextResponse.json({ error: "Email required" }, { status: 400 });

  const brevoKey = process.env.BREVO_API_KEY;
  const brevoList = process.env.BREVO_LIST_ID;
  const mcKey = process.env.MAILCHIMP_API_KEY;
  const mcPrefix = process.env.MAILCHIMP_SERVER_PREFIX;
  const mcList = process.env.MAILCHIMP_LIST_ID;

  try {
    if (brevoKey && brevoList) {
      // Brevo API v3
      const res = await fetch("https://api.brevo.com/v3/contacts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "api-key": brevoKey,
        },
        body: JSON.stringify({
          email,
          listIds: [Number(brevoList)],
          updateEnabled: true
        }),
      });
      if (!res.ok) {
        const t = await res.text();
        return NextResponse.json({ error: t || "Brevo error" }, { status: 500 });
      }
      return NextResponse.json({ ok: true });
    }

    if (mcKey && mcPrefix && mcList) {
      // Mailchimp API
      const url = `https://${mcPrefix}.api.mailchimp.com/3.0/lists/${mcList}/members`;
      const res = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `apikey ${mcKey}`,
        },
        body: JSON.stringify({ email_address: email, status: "subscribed" }),
      });
      if (!res.ok) {
        const t = await res.text();
        return NextResponse.json({ error: t || "Mailchimp error" }, { status: 500 });
      }
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({
      error: "No provider configured. Set BREVO_* or MAILCHIMP_* env vars.",
    }, { status: 501 });

  } catch (err: any) {
    return NextResponse.json({ error: err?.message || "Unknown error" }, { status: 500 });
  }
}
