'use client';
import { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import { dict, type Lang } from '@/components/i18n';
import { buildMerkle } from '@/lib/merkle';

const FACTORY = process.env.NEXT_PUBLIC_AIRDROP_FACTORY || '0xYourAirdropFactory';
const factoryAbi = [
  "function createDistributor(bytes32 root) onlyOwner returns (address)",
  "function getAll() view returns (address[])"
];

export default function AirdropPage() {
  const [lang, setLang] = useState<Lang>('en');
  const t = dict[lang];
  const [csv, setCsv] = useState("0xabc...,1000\n0xdef...,2000");
  const [root, setRoot] = useState<string>('');
  const [distributor, setDistributor] = useState<string>('');
  const [status, setStatus] = useState<string>('');

  function parseCsv() {
    const rows = csv.split(/\r?\n/).map(l=>l.trim()).filter(Boolean);
    return rows.map((line, idx) => {
      const [addr, amt] = line.split(/,|;|\t/).map(s=>s.trim());
      return { index: idx, account: addr, amount: BigInt(amt) };
    });
  }

  function computeRoot() {
    const leaves = parseCsv();
    const { root } = buildMerkle(leaves);
    setRoot(root);
  }

  async function deployDistributor() {
    try {
      const provider = new ethers.BrowserProvider((window as any).ethereum);
      const signer = await provider.getSigner();
      const factory = new ethers.Contract(FACTORY, factoryAbi, signer);
      setStatus('Deploying...');
      const tx = await factory.createDistributor(root);
      const rcpt = await tx.wait();
      setStatus('Deployed');
      // Fetch latest distributor
      const list = await factory.getAll();
      setDistributor(list[list.length-1]);
    } catch (e:any) {
      setStatus(e.message || 'Error');
    }
  }

  return (
    <main className="min-h-screen bg-[#0b0b0f] text-white px-6 py-10">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-semibold">{t.airdropTitle}</h1>
          <select value={lang} onChange={e=>setLang(e.target.value as Lang)} className="bg-white/10 border border-white/15 rounded-lg px-3 py-2 text-sm">
            {Object.entries(dict).map(([k,v])=> <option key={k} value={k}>{v.langName}</option>)}
          </select>
        </div>
        <p className="text-white/70">{t.airdropDesc}</p>

        <div className="rounded-2xl border border-white/15 bg-white/5 p-4 space-y-3">
          <label className="text-sm">CSV (address, amount)</label>
          <textarea value={csv} onChange={e=>setCsv(e.target.value)} rows={6} className="w-full rounded-xl bg-white/10 px-4 py-3 outline-none ring-1 ring-white/15 focus:ring-2 focus:ring-emerald-400"></textarea>
          <div className="flex gap-2">
            <button onClick={computeRoot} className="rounded-xl px-4 py-2 bg-white text-black">Compute Merkle Root</button>
            <button onClick={deployDistributor} disabled={!root} className="rounded-xl px-4 py-2 border border-white/15 bg-white/10 disabled:opacity-40">Deploy Distributor</button>
          </div>
          <div className="text-xs text-white/70 break-all">Root: {root || "—"}</div>
          <div className="text-xs text-white/70 break-all">Distributor: {distributor || "—"}</div>
          <div className="text-xs text-white/70">{status}</div>
        </div>
      </div>
    </main>
  );
}
