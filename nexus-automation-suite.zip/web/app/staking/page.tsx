'use client';

import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';

// ======= CONFIG =======
// Replace with your deployed addresses:
const TOKEN_ADDRESS = process.env.NEXT_PUBLIC_NEX_TOKEN_ADDRESS || '0xYourNEXAddress';
const STAKING_ADDRESS = process.env.NEXT_PUBLIC_STAKING_ADDRESS || '0xYourStakingAddress';

// Minimal ABIs
const erc20Abi = [
  "function decimals() view returns (uint8)",
  "function symbol() view returns (string)",
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address,address) view returns (uint256)",
  "function approve(address,uint256) returns (bool)"
];

const stakingAbi = [
  "function stake(uint256 amount)",
  "function withdraw(uint256 amount)",
  "function getReward()",
  "function exit()",
  "function earned(address) view returns (uint256)",
  "function balances(address) view returns (uint256)",
  "function totalSupply() view returns (uint256)",
  "function rewardRate() view returns (uint256)",
  "function periodFinish() view returns (uint256)"
];

export default function StakingPage() {
  const [account, setAccount] = useState<string>('');
  const [provider, setProvider] = useState<ethers.BrowserProvider>();
  const [signer, setSigner] = useState<ethers.Signer>();
  const [symbol, setSymbol] = useState<string>('NEX');
  const [decimals, setDecimals] = useState<number>(18);
  const [bal, setBal] = useState<string>('0');
  const [staked, setStaked] = useState<string>('0');
  const [rewards, setRewards] = useState<string>('0');
  const [amount, setAmount] = useState<string>('');
  const [status, setStatus] = useState<string>('');

  const token = useMemo(() => (signer ? new ethers.Contract(TOKEN_ADDRESS, erc20Abi, signer) : null), [signer]);
  const staking = useMemo(() => (signer ? new ethers.Contract(STAKING_ADDRESS, stakingAbi, signer) : null), [signer]);

  async function connect() {
    if (!window.ethereum) return alert("MetaMask not found");
    const prov = new ethers.BrowserProvider(window.ethereum as any);
    const acc = await prov.send('eth_requestAccounts', []);
    const s = await prov.getSigner();
    setProvider(prov);
    setSigner(s);
    setAccount(acc[0]);
  }

  function fmt(x: bigint) {
    return Number(ethers.formatUnits(x, decimals)).toLocaleString(undefined, { maximumFractionDigits: 6 });
  }

  async function refresh() {
    if (!signer || !token || !staking || !account) return;
    const [dec, sym] = await Promise.all([token.decimals(), token.symbol()]);
    setDecimals(Number(dec));
    setSymbol(sym);
    const [b, st, er] = await Promise.all([token.balanceOf(account), staking.balances(account), staking.earned(account)]);
    setBal(fmt(b));
    setStaked(fmt(st));
    setRewards(fmt(er));
  }

  async function ensureApproval(wei: bigint) {
    if (!token || !account) return;
    const allowance = await token.allowance(account, STAKING_ADDRESS);
    if (allowance < wei) {
      setStatus('Approving...');
      const tx = await token.approve(STAKING_ADDRESS, ethers.MaxUint256);
      await tx.wait();
    }
  }

  async function handleStake() {
    if (!staking || !amount) return;
    try {
      const wei = ethers.parseUnits(amount, decimals);
      await ensureApproval(wei);
      setStatus('Staking...');
      const tx = await staking.stake(wei);
      await tx.wait();
      setStatus('Staked!');
      setAmount('');
      await refresh();
    } catch (e:any) {
      setStatus(e.message || 'Error');
    }
  }

  async function handleWithdraw() {
    if (!staking || !amount) return;
    try {
      const wei = ethers.parseUnits(amount, decimals);
      setStatus('Withdrawing...');
      const tx = await staking.withdraw(wei);
      await tx.wait();
      setStatus('Withdrawn');
      setAmount('');
      await refresh();
    } catch (e:any) {
      setStatus(e.message || 'Error');
    }
  }

  async function handleClaim() {
    if (!staking) return;
    try {
      setStatus('Claiming...');
      const tx = await staking.getReward();
      await tx.wait();
      setStatus('Claimed');
      await refresh();
    } catch (e:any) {
      setStatus(e.message || 'Error');
    }
  }

  async function handleExit() {
    if (!staking) return;
    try {
      setStatus('Exiting...');
      const tx = await staking.exit();
      await tx.wait();
      setStatus('Exited');
      await refresh();
    } catch (e:any) {
      setStatus(e.message || 'Error');
    }
  }

  useEffect(() => { refresh(); }, [signer, account]);

  return (
    <main className="min-h-screen bg-[#0b0b0f] text-white px-6 py-10">
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-3xl font-semibold">NEX Staking</h1>
        {!account ? (
          <button onClick={connect} className="rounded-xl px-4 py-2 bg-white text-black">Connect Wallet</button>
        ) : (
          <div className="text-sm text-white/80 break-all">Connected: {account}</div>
        )}

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="rounded-xl bg-white/5 border border-white/10 p-4">Balance: <b>{bal}</b> {symbol}</div>
          <div className="rounded-xl bg-white/5 border border-white/10 p-4">Staked: <b>{staked}</b> {symbol}</div>
          <div className="rounded-xl bg-white/5 border border-white/10 p-4">Rewards: <b>{rewards}</b> {symbol}</div>
        </div>

        <div className="rounded-2xl bg-white/5 border border-white/10 p-4 space-y-3">
          <label className="text-sm">Amount ({symbol})</label>
          <input value={amount} onChange={(e)=>setAmount(e.target.value)} placeholder="0.0" className="w-full rounded-xl bg-white/10 px-4 py-3 outline-none ring-1 ring-white/15 focus:ring-2 focus:ring-emerald-400" />
          <div className="flex flex-wrap gap-2">
            <button onClick={handleStake} className="rounded-xl px-4 py-2 bg-white text-black">Stake</button>
            <button onClick={handleWithdraw} className="rounded-xl px-4 py-2 border border-white/15 bg-white/10 hover:bg-white/20">Withdraw</button>
            <button onClick={handleClaim} className="rounded-xl px-4 py-2 border border-white/15 bg-white/10 hover:bg-white/20">Claim</button>
            <button onClick={handleExit} className="rounded-xl px-4 py-2 border border-white/15 bg-white/10 hover:bg-white/20">Exit</button>
          </div>
          <div className="text-xs text-white/70">{status}</div>
        </div>
      </div>
    </main>
  );
}
