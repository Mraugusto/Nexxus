'use client';
import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';
import { dict, type Lang } from '@/components/i18n';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const STAKING_ADDRESS = process.env.NEXT_PUBLIC_STAKING_ADDRESS || '0xYourStakingAddress';

const stakingAbi = [
  "function totalSupply() view returns (uint256)",
  "function rewardRate() view returns (uint256)"
];

export default function Dashboard() {
  const [lang, setLang] = useState<Lang>('en');
  const t = dict[lang];
  const [apr, setApr] = useState<number>(0);
  const [staked, setStaked] = useState<string>('0');

  async function refresh() {
    try {
      const provider = new ethers.BrowserProvider((window as any).ethereum);
      const staking = new ethers.Contract(STAKING_ADDRESS, stakingAbi, await provider.getSigner());
      const [ts, rr] = await Promise.all([staking.totalSupply(), staking.rewardRate()]);
      const yearly = Number(rr) * 31536000;
      const aprVal = Number(ts) > 0 ? (yearly / Number(ts)) * 100 : 0;
      setApr(aprVal);
      setStaked(ethers.formatUnits(ts, 18));
    } catch {
      // fallback demo values
      setApr(18.5);
      setStaked("25000000");
    }
  }

  useEffect(()=>{ refresh(); }, []);

  // Mock historical series
  const data = Array.from({length: 30}).map((_,i)=>({ day: i+1, tvl: 20 + Math.sin(i/5)*2 + i*0.1 }));

  return (
    <main className="min-h-screen bg-[#0b0b0f] text-white px-6 py-10">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-semibold">{t.dashboardTitle}</h1>
          <select value={lang} onChange={e=>setLang(e.target.value as Lang)} className="bg-white/10 border border-white/15 rounded-lg px-3 py-2 text-sm">
            {Object.entries(dict).map(([k,v])=> <option key={k} value={k}>{v.langName}</option>)}
          </select>
        </div>
        <p className="text-white/70 mb-6">{t.dashboardDesc}</p>
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="rounded-2xl bg-white/5 border border-white/10 p-5">
            <div className="text-sm text-white/70">{t.tvl}</div>
            <div className="text-3xl font-semibold">{Number(staked).toLocaleString()}</div>
          </div>
          <div className="rounded-2xl bg-white/5 border border-white/10 p-5">
            <div className="text-sm text-white/70">{t.apr}</div>
            <div className="text-3xl font-semibold">{apr.toFixed(2)}%</div>
          </div>
          <div className="rounded-2xl bg-white/5 border border-white/10 p-5">
            <div className="text-sm text-white/70">Distributions</div>
            <div className="text-3xl font-semibold">—</div>
          </div>
        </div>
        <div className="rounded-2xl bg-white/5 border border-white/10 p-5 h-[360px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="tvl" stroke="#82ca9d" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </main>
  );
}
