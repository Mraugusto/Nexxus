"use client";

import { useState } from "react";
import type { Lang } from "./i18n";

export default function NewsletterForm({ lang = "en" as Lang }) {
  const [email, setEmail] = useState("");
  const [agree, setAgree] = useState(false);
  const [status, setStatus] = useState<"idle"|"loading"|"success"|"error">("idle");
  const [message, setMessage] = useState<string>("");

  const labels = {
    en: {
      email: "Your email",
      agree: "I agree to receive emails and the Privacy Policy.",
      button: "Subscribe",
      ok: "You're in! Check your inbox.",
      err: "Subscription failed. Try again or contact support."
    },
    pt: {
      email: "Seu email",
      agree: "Concordo em receber emails e com a Política de Privacidade.",
      button: "Inscrever",
      ok: "Pronto! Verifique seu email.",
      err: "Falha ao inscrever. Tente novamente ou contacte o suporte."
    }
  }[lang];

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !agree) return;
    setStatus("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setStatus("success");
      setMessage(labels.ok);
      setEmail("");
      setAgree(false);
    } catch (err) {
      console.error(err);
      setStatus("error");
      setMessage(labels.err);
    }
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl border border-white/15 bg-white/5 p-4 md:p-6 space-y-3">
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder={labels.email}
          className="flex-1 rounded-xl bg-white/10 px-4 py-3 outline-none ring-1 ring-inset ring-white/15 focus:ring-2 focus:ring-emerald-400"
          required
        />
        <button
          disabled={!agree || status === "loading"}
          className="rounded-xl px-5 py-3 bg-white text-black font-medium disabled:opacity-50"
        >
          {status === "loading" ? "…" : labels.button}
        </button>
      </div>
      <label className="text-xs text-white/80 flex items-center gap-2">
        <input type="checkbox" checked={agree} onChange={(e)=>setAgree(e.target.checked)} className="accent-emerald-400" /> {labels.agree}
      </label>
      {status !== "idle" && <div className="text-xs">{message}</div>}
    </form>
  );
}
