# Domain, DNS & Deploy (Vercel)

## 1) Add your domain
- In Vercel Dashboard → **Settings → Domains** → Add `yourdomain.com`.
- Choose apex (`yourdomain.com`) and add `www` as subdomain redirect to apex (or vice-versa).

## 2) DNS Records
**Option A: Use Vercel Nameservers (simplest)**
- Point your registrar to Vercel nameservers shown in the dashboard.

**Option B: Keep your registrar's DNS (manual records)**
- Apex: create **A** records to Vercel edge IPs (managed in Vercel; you’ll be prompted).
- Or use **ALIAS/ANAME** if your DNS supports it.
- `www` (or any subdomain): create **CNAME** → `cname.vercel-dns.com`.

## 3) Environment Variables
Create in Vercel → Project Settings → **Environment Variables**:
- (Optional) `NEXT_PUBLIC_GA_ID` for Google Analytics 4.
- Newsletter (choose one provider):
  - Brevo: `BREVO_API_KEY` and `BREVO_LIST_ID`
  - Mailchimp: `MAILCHIMP_API_KEY`, `MAILCHIMP_SERVER_PREFIX`, `MAILCHIMP_LIST_ID`

## 4) Build & Deploy
- Push the repo to GitHub, import in Vercel.
- Build command: `next build` (default).
- After deploy, verify:
  - `https://yourdomain.com` loads.
  - Meta tags / OG image (check `View Source`).
  - `/api/subscribe` returns 501 until provider keys are set.
  - Analytics events visible in GA4/Vercel Analytics.

## 5) Security & Best Practices
- Enable **Redirect www → apex** (or opposite) to avoid duplicate content.
- Add **DNSSEC** at your registrar (if supported).
- Turn on **Protection** for main branch and require PR reviews.
