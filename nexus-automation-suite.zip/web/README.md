# Nexus Protocol — Landing Page (Next.js + Tailwind)

Production-ready landing page with PT/EN toggle, newsletter form and a serverless `/api/subscribe` route supporting **Brevo** or **Mailchimp**.

## Tech
- Next.js 14 (App Router)
- Tailwind CSS
- Framer Motion, lucide-react, recharts

## Quickstart
```bash
pnpm i   # or npm i / yarn
pnpm dev # http://localhost:3000
```

## Configure newsletter
Create `.env.local` and set **one** provider:

### Brevo (recommended)
```
BREVO_API_KEY=your_brevo_api_key
BREVO_LIST_ID=123456
```

### Mailchimp
```
MAILCHIMP_API_KEY=your_mailchimp_api_key
MAILCHIMP_SERVER_PREFIX=us21
MAILCHIMP_LIST_ID=xxxxxxxxxx
```

## Deploy to Vercel
1. Push this repo to GitHub.
2. Import in Vercel → set the environment variables above.
3. Deploy. The API route `/api/subscribe` will use your provider.

## Customize
- Edit texts in `components/i18n.ts`.
- Replace `public/logo.svg`.
- Adjust tokenomics chart in `app/page.tsx`.
- Tailwind config in `tailwind.config.ts`.

## Staking & Vesting UIs
- **/staking** – Connect wallet, stake/withdraw/claim/exit for NEX.
  - Set env: `NEXT_PUBLIC_NEX_TOKEN_ADDRESS` and `NEXT_PUBLIC_STAKING_ADDRESS`.
- **/vesting** – Factory UI to batch-create vesting contracts from CSV.
  - Set env: `NEXT_PUBLIC_VESTING_FACTORY`.

> NOTE: Replace placeholder addresses with your deployed contracts. ABIs are embedded with the minimal functions required.

## New pages
- `/dashboard` — APR & staking totals (estimates from contract).
- `/airdrop` — Build a Merkle root from CSV and deploy a distributor via factory.
- `/explorer` — Query vestings by beneficiary and view releasable amounts.

## Airdrop (Merkle)
Contracts:
- `NexusMerkleDistributor.sol`
- `NexusMerkleDistributorFactory.sol`

Env:
- `NEXT_PUBLIC_AIRDROP_FACTORY` — address of the distributor factory.

Merkle leaf: `keccak256(abi.encode(index, account, amount))`. The UI computes root client-side (`lib/merkle.ts`).

## Languages
The UI supports **English, Español, Français, Deutsch, Português, 中文, 日本語**.
