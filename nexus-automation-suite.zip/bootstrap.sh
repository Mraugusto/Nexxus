#!/usr/bin/env bash
set -euo pipefail

# Simple bootstrap to deploy to Sepolia and run the web locally
pushd contracts >/dev/null

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Edit contracts/.env with PRIVATE_KEY and ALCHEMY_KEY, then re-run this script."
  exit 1
fi

npm i
npm run compile
npm run deploy:sepolia

popd >/dev/null
pushd web >/dev/null
npm i
npm run dev
